# frozen_string_literal: true

require 'api-umbrella-status-checks/version'